alias mc 'source /data/local/tmp/Sshd4a/share/mc/libexec/mc/mc-wrapper.csh'
